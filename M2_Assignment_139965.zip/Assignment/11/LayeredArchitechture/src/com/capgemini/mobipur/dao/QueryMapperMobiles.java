package com.capgemini.mobipur.dao;

public interface QueryMapperMobiles {

	public static final String UPDATE_MOBILE=
			"UPDATE mobiles SET quantity=? WHERE mobileid=?";

	public static final String DELETE_MOBILE=
			"DELETE FROM mobiles WHERE mobileid=?";
	
	public static final String VIEW_MOBILE=
			"SELECT mobileid,name,price,quantity FROM mobiles";
	
	public static final String SEARCH_MOBILE=
			"SELECT mobileid,name,price,quantity FROM mobiles WHERE price BETWEEN ? AND ?";
	
	public static final String GET_MOBILES=
			"SELECT quantity FROM mobiles WHERE mobileId=?";
	
}
