package com.capgemini.mobipur.Test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.mobipur.bean.PurchaseDetailsBean;
import com.capgemini.mobipur.exception.MobilePurchaseException;
import com.capgemini.mobipur.service.IServicePurchaseMobile;
import com.capgemini.mobipur.service.ServicePurchaseImpl;

public class ServicePurchaseImplTest {

	private PurchaseDetailsBean purchaseDetailsBean;
	
	@Before
	public void setUp() throws Exception {
		purchaseDetailsBean=new PurchaseDetailsBean("abc","abc@gmail.com","99888",1002);
	}

	@After
	public void tearDown() throws Exception {
		purchaseDetailsBean=null;
	}

	@Test
	public final void testInsertPurchaseDetails() {

		IServicePurchaseMobile servicePurchaseMobile=new ServicePurchaseImpl();
		
		try
		{
			assertTrue(servicePurchaseMobile.insertPurchaseDetails(purchaseDetailsBean));
		}
		catch(MobilePurchaseException e)
		{
			e.printStackTrace();
		}
	}

}
