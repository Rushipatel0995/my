public class PersonMain {

	public static void main(String[] args) {
		
		String fname;
		String lname;
		char gender;
		long phoneNumber;
		
		Scanner scInput = new Scanner(System.in);
		
		Person person = new Person("Rushi","PAtel",'M');
		
		System.out.println("Enter your mobile number");
		phoneNumber=scInput.nextLong();
					scInput.nextLine();
		
		person.setPhoneNumber(phoneNumber);
		
		person.output();
	}
}