package Caller;

import java.util.Scanner;

public class StringDemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=new String();
		int choice;
		
		System.out.println("Enter the string: ");
		s=sc.nextLine();
		
		System.out.println("Enter your choice: ");
		System.out.println("1. Add the String to itself");
		System.out.println("2. Replace odd positions with #");
		System.out.println("3. Remove duplicate characters in the String");
		System.out.println("4. Change odd characters to upper case");
		choice=Integer.parseInt(sc.nextLine());
		
		switch(choice)
		{
		case 1: appendString(s);
				break;
		case 2: replaceWith(s);
				break;
		case 3: removeDuplicate(s);
				break;
		case 4: changeCase(s);
				break;
		default:System.out.println("Invalid Input");
				break;
		}
		sc.close();
	}
	
	public static void appendString(String s)
	{
		StringBuffer result=new StringBuffer(s);
		result.append(s);
		System.out.println("After Appending: " +result);
	}
	
	public static void replaceWith(String s)
	{
		String result=new String(s);
		int Length=s.length();
		for (int i=0; i <= Length; i++){
	        if (i % 2 != 0){
	          result = result.substring(0,i-1) + "#" + result.substring(i,Length);
	        }
	      }
		System.out.println("After Replacing: "+result);
	}
	
	public static void removeDuplicate(String s)
	{
		String result = "";
		for (int i = 0; i < s.length(); i++) {
			if(!result.contains(String.valueOf(s.charAt(i)))) {
				result += String.valueOf(s.charAt(i));
		     }
		}
		System.out.println("After Removing Duplicate characters : "+result);
	}
	
	public static void changeCase(String s)
	{
		String result=s.toUpperCase();
		System.out.println("After Changing to Upper Case: "+result);
	}
}
