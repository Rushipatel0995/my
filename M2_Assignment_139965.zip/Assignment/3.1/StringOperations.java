import java.util.Scanner;

public class StringOperations {

	public static void main(String[] args) {
		
		String str;
		int choice;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter a String");
		str=sc.nextLine();
		
		System.out.println("Enter your choice");
		System.out.println("1. Add the string to itself");
		System.out.println("2. Replace odd positions with #");
		System.out.println("3. Remove duplicate characters in the string");
		System.out.println("4. Change odd characters to upper case");
		System.out.println("Enter 1, 2, 3 or 4");
		choice=sc.nextInt();
		
		switch(choice){
		case 1:
			str=str.concat(str);
			break;
		case 2:
			char[] s=str.toCharArray();
			int length=s.length;
			for(int i=0;i<length;++i){
				if(i%2!=0){
					s[i]='#';
				}
			}
			str = String.valueOf(s);
			break;
		case 3:
			String result = "";
		    for (int i = 0; i < str.length(); i++) {
		        if(!result.contains(String.valueOf(str.charAt(i)))) {
		            result += String.valueOf(str.charAt(i));
		        }
		    }
		    str= result;
		    break;
		case 4:
			char[] s1=str.toCharArray();
			int length1=s1.length;
			for(int i=0;i<length1;++i){
				if(i%2!=0){
					s1[i]=Character.toUpperCase(s1[i]);
				}else{
					s1[i]=Character.toLowerCase(s1[i]);
				}
			}
			str = String.valueOf(s1);
			break;
		default:
			System.out.println("You didn't have choosen a correct option");
			break;
		}
		
		System.out.println(str);
		sc.close();
	}

}
