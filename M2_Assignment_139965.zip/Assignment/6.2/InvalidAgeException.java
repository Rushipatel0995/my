
public class InvalidAgeException extends Exception {
	public InvalidAgeException(String s){
        // Call constructor of parent Exception
        super(s);
    }
}
