DECLARE
	v_employee Employee%ROWTYPE;
	not_found EXCEPTION;
	
BEGIN
	
	SELECT *
	INTO v_employee
	FROM Employee
	WHERE Employee_no = 7369;
	
	IF v_employee.Commission='no' THEN
		RAISE not_found;
	END IF;
	
	DBMS_OUTPUT.PUT_LINE('commission found');

EXCEPTION
	WHEN not_found THEN
		DBMS_OUTPUT.PUT_LINE('no commission');

END;
/