CREATE TABLE Staff_Master(
	Staff_Code NUMBER(5),
	Staff_Name VARCHAR(15),
	Staff_Sal NUMBER(10),
	Mgr_Code NUMBER(10),
	Mgr_Name VARCHAR(15),
	Department_no NUMBER(3,0) REFERENCES Department(Department_no)
);

INSERT INTO Staff_Master VALUES(1,'bijoy',5000,100006,'durjoy',1);
INSERT INTO Staff_Master VALUES(2,'bijoya',4600,100043,'djoyla',2);
INSERT INTO Staff_Master VALUES(4,'joy',5643,100002,'lata',3);
INSERT INTO Staff_Master VALUES(3,'bijsdfy',5320,100008,'debsa',4);
INSERT INTO Staff_Master VALUES(5,'dad',4500,100406,'farin',5);