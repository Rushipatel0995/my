DECLARE --outer block
	var_num1 NUMBER := 5;
BEGIN
	DECLARE --inner block
		var_num1 NUMBER := 10;
	
	BEGIN
		DBMS_OUTPUT.PUT_LINE('Value for var_num1:' ||var_num1);
		--NO outer block variable (var_num1) cannot be printed here.
	END;
	DBMS_OUTPUT.PUT_LINE('Value for var_num1:' ||var_num1);
	--NO inner block variable (var_num1) cannot be printed here.
END;
/