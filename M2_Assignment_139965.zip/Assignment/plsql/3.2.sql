CREATE OR REPLACE PROCEDURE details(
	v_staff_code IN Staff_Master.Staff_Code%TYPE,
	v_staff_name OUT Staff_Master.Staff_Name%TYPE,
	v_dept_name OUT Department.Department_Name%TYPE,
	v_mgr_name OUT Staff_Master.Mgr_Name%TYPE,
	v_errmsg OUT VARCHAR2
)

IS
	v_dept_no Department.Department_no%TYPE;

BEGIN
	
	SELECT Staff_Name,Department_no,Mgr_Name
	INTO v_staff_name,v_dept_no,v_mgr_name
	FROM Staff_Master
	WHERE Staff_Code = v_staff_code;
	
	SELECT  Department_Name
	INTO v_dept_name
	FROM Department
	WHERE Department_no = v_dept_no;
	
	EXCEPTION
		WHEN OTHERS THEN
			v_errmsg := SQLERRM;

END;
/
	
	
	