package Caller;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class timeZone {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		ZonedDateTime currentTime;
		
		System.out.println("Enter your time zone: ");
		System.out.println("1. America/New_York: ");
		System.out.println("2. Europe/London: ");
		System.out.println("3. Asia/Tokyo: ");
		System.out.println("4. US/Pacific: ");
		System.out.println("5. Africa/Cairo: ");
		System.out.println("6. Australia/Sydney: ");
		int dt=sc.nextInt();
		
		switch(dt)
		{
		case 1: currentTime=ZonedDateTime.now(ZoneId.of("America/New_York"));
				System.out.println("New York Time: "+currentTime);
				break;
		case 2: currentTime=ZonedDateTime.now(ZoneId.of("Europe/London"));
				System.out.println("London Time: "+currentTime);
				break;
		case 3: currentTime=ZonedDateTime.now(ZoneId.of("Asia/Tokyo"));
				System.out.println("Tokyo Time: "+currentTime);
				break;
		case 4: currentTime=ZonedDateTime.now(ZoneId.of("US/Pacific"));
				System.out.println("Pecific Time: "+currentTime);
				break;
		case 5: currentTime=ZonedDateTime.now(ZoneId.of("Africa/Cairo"));
				System.out.println("Cairo Time: "+currentTime);
				break;
		case 6: currentTime=ZonedDateTime.now(ZoneId.of("Australia/Sydney"));
				System.out.println("Sydney Time: "+currentTime);
				break;
		default: System.out.println("Wrong Input");
				 break;
		}
		
		sc.close();

	}

}
