package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class EmployeeMain {

	public static void main(String[] args) {
		
		long id;
		String name;
		double salary;
		String designation;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Employee Details: ");
		
		System.out.println("Enter Employee Id: ");
		id=sc.nextLong();
		sc.nextLine();
		
		System.out.println("Enter Employee Name: ");
		name=sc.nextLine();
		
		System.out.println("Enter Employee Salary: ");
		salary=sc.nextInt();
		sc.nextLine();
		
		System.out.println("Enter Employee Designation: ");
		designation=sc.nextLine();
		
		Employee emp=new Employee();
		
		emp.setData(id, name, salary, designation);
		emp.findScheme();
		emp.display();
		
		sc.close();

	}

}
