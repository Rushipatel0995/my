package com.cg.eis.bean;

import com.cg.eis.service.EmployeeService;

public class Employee implements EmployeeService {

	protected long id;
	protected String name;
	protected double salary;
	protected String designation;
	protected String insuranceScheme;
	
	@Override
	public void setData(long id, String name, double salary, String designation) {
		
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.designation = designation;
		
		if(salary<5000 && designation.equals("Clerk"))
			this.insuranceScheme = "No Scheme";
		else if(salary>5000 && salary<20000 && designation.equals("System Associate"))
			this.insuranceScheme = "Scheme C";
		else if(salary>=20000 && salary<40000 && designation.equals("Programmer"))
			this.insuranceScheme = "Scheme B";
		else if(salary>=40000 && designation.equals("Manager"))
			this.insuranceScheme = "Scheme A";
		
	}

	@Override
	public void findScheme() {
		
		if(salary<5000 && designation.equals("Clerk"))
			System.out.println("No Scheme");
		else if(salary>5000 && salary<20000 && designation.equals("System Associate"))
			System.out.println("Scheme C");
		else if(salary>=20000 && salary<40000 && designation.equals("Programmer"))
			System.out.println("Scheme B");
		else if(salary>=40000 && designation.equals("Manager"))
			System.out.println("Scheme A");
		else
			System.out.println("Wrong Input");
		
	}

	@Override
	public void display() {
		
		System.out.println("Details of employee: ");
		System.out.println("Id: "+id);
		System.out.println("Name: "+name);
		System.out.println("Salary: "+salary);
		System.out.println("Designation: "+designation);
		System.out.println("Insurance Scheme: "+insuranceScheme);

	}

}
