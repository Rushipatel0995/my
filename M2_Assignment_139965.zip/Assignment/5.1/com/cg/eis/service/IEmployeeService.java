package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public interface IEmployeeService {

	public void getEmployeeDetails(Employee employee);
	public void setInsuranceScheme(Employee employee);
	public void showEmployeeDetails(Employee employee);
}
