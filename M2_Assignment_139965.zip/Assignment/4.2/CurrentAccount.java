public class CurrentAccount extends Account {
	
	private final double overdraft = 500;
	
	public CurrentAccount(){
		super();
	}
	
	public CurrentAccount(double balance, Person accHolder){
		super(balance,accHolder);
	}
	
	public boolean withdraw(double amount){
		double newBalance;
		if(this.getBalance()-amount>overdraft){
			newBalance=this.getBalance()-amount;
			this.setBalance(newBalance);
			return true;
		}else{
			return false;
		}
	}
}

