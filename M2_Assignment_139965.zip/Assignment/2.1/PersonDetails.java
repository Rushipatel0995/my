public class PersonDetails {

	public static void main(String[] args) {
		
		System.out.println("Person Details");
		System.out.println("-------------------");
		System.out.println("First Name: Rushi");
		System.out.println("Last Name: petel");
		System.out.println("Gender: F");
		System.out.println("Age: 21");
		System.out.println("Weight: 30.30");

	}
}