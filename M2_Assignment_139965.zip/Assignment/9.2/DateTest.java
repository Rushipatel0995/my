import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class DateTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testDate() {
		Date date = new Date(22,01,1995);
		assertEquals(22,date.getDay());
		assertEquals(01,date.getMonth());
		assertEquals(1995,date.getYear());
	}

	@Test
	public final void testSetDay() {
		Date date = new Date();
		date.setDay(22);
		assertEquals(date.getDay(),22);
	}

	@Test
	public final void testGetDay() {
		Date date = new Date(22,01,1995);
		assertEquals(22,date.getDay());
	}

	@Test
	public final void testSetMonth() {
		Date date = new Date();
		date.setMonth(01);
		assertEquals(date.getMonth(),01);
	}

	@Test
	public final void testGetMonth() {
		Date date = new Date(22,01,1995);
		assertEquals(01,date.getMonth());
	}

	@Test
	public final void testSetYear() {
		Date date = new Date();
		date.setYear(1995);
		assertEquals(date.getYear(),1995);
	}

	@Test
	public final void testGetYear() {
		Date date = new Date(22,01,1995);
		assertEquals(1995,date.getYear());
	}

	@Test
	public final void testToString() {
		Date date = new Date(22,01,1995);
		String result = "Date is 22/1/1995";
		assertEquals(date.toString(),result);
	}

}