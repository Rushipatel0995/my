package com.cg.eis.service;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public interface IEmployeeService {

	public void getEmployeeDetails(Employee employee)throws EmployeeException;
	public void setInsuranceScheme(Employee employee);
	public void showEmployeeDetails(Employee employee);
}
