package Caller;

public class SavingsAccount extends Account {

	final double minBalance=1000;
	
	public boolean withdraw(double d)
	{
		double temp=this.balance-d;
		if(temp>minBalance)
		{
			this.balance=temp;
			return true;
		}
		else
			return false;
	}
}
