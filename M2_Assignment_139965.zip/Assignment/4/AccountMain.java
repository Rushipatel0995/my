package Caller;

public class AccountMain {

	public static void main(String[] args) {
		
		PersonAccount p1=new PersonAccount("Smith",34);
		PersonAccount p2=new PersonAccount("Kathy",43);
		
		Account a1=new Account(2000,p1);
		Account a2=new Account(3000,p2);
		
		a1.deposit(2000);
		
		boolean b=a2.withdraw(2000);
		
		if(b==true)
			System.out.println("Balance updated.");
		else
			System.out.println("Balance not updated.");
		
		System.out.println("Updated Balance: ");
		System.out.println("Smith's Balance: "+a1.getBalance());
		System.out.println("Kathy's Balance: "+a2.getBalance());
		
		String s1=a1.toString();
		String s2=a2.toString();
		
		System.out.println(s1);
		System.out.println(s2);
	}

}
