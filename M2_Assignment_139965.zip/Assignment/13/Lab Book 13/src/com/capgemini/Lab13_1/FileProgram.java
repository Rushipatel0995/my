package com.capgemini.Lab13_1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class FileProgram {

	public static void main(String[] args) {
		File fileRead = new File("src/source.txt");
		File fileWrite = new File("src/target.txt");
		FileInputStream fis;
		try {
			fis = new FileInputStream(fileRead);
			FileOutputStream fos = new FileOutputStream(fileWrite);
			Thread t1 = new CopyDataThread(fis, fos);
			t1.start();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

}
