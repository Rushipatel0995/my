package com.capgemini.lab146.client;

import java.util.Scanner;

import com.capgemini.lab146.entity.EmployeeRepository;

public class EmployeeService {

public static void main(String[] args) {
EmployeeRepository emplRepo = new EmployeeRepository();
Scanner sc = new Scanner(System.in);
int ch;
System.out.println("1. Sum of all Salaries \n 2.List Employees with months & days \n 3.Employees without department \n 4. Only departments \n 5. Employees & day of week of hiring");
 

System.out.println("Enter your Choice: ");
ch = sc.nextInt();

switch(ch)
{
case 1:
System.out.println("Sum of all salaries: " + emplRepo.getAllSalarySum());
break;
case 2: 
emplRepo.listEmployeesMonthDays();
break;  
case 3: 
emplRepo.employeesWithoutDepartment();
break;  
case 4:
emplRepo.onlyDepartments();
break;
case 5: 
emplRepo.dayOfWeek();
break;

default:
System.out.println("Enter proper Choice");
}
}

}
