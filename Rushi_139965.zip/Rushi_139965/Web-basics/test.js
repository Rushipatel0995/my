
/*function to validate dropdownlist*/
function valid(){
	if(document.getElementById("id1").value == "")
   {
      alert("Please select value"); // prompt user
      document.getElementById("id1").focus(); //set focus back to control
      return false;
   }

}
/* Function to show the details in alert*/
function show(){
	if(document.getElementById('salary').value<0)
	{
		alert('Please enter a positive amount!');
	}
	var fnam=document.getElementById('fname').value;
	var lnam=document.getElementById('lname').value;
	var grd1=document.getElementsByName('grad');
	
	var grdlc;
	for(var i=0;i < grd1.length; i++)
	{
	if(grd1[i].checked)
	{
	grdlc=grd1[i].value;
	}
	}
	var qlfy=document.getElementById('qual');
	var qlfyc=qlfy.options[qlfy.selectedIndex].text;
	



alert('All data for '+qlfyc+' '+fnam+' '+lnam+' entered successfully!');

}