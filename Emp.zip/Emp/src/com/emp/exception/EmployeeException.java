package com.emp.exception;

public class EmployeeException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7585481158636249909L;
	public EmployeeException() {
		super();
	}

	public EmployeeException(String message) {
		super(message);
	}	
}
