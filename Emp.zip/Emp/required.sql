create table emp2(employeeid number(10) primary key, employeename varchar2(30), salary number(10), departmentname varchar2(20), designation varchar2(20));


create sequence emp_sequence1
start with 1001;